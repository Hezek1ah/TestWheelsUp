﻿//Last edited by Kelly Bagley, 7/8/2021
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;

namespace WheelsUpPages
{
    public static class MoveToElement
    {
        public static IWebElement Go(IWebDriver driver, string elementXPath)
        {
            if (driver is null) throw new Exception("Driver cannot be null.");
            if (elementXPath == string.Empty) throw new Exception("Element XPath cannot be empty string.");
            IWebElement element = driver.FindElement(By.XPath(elementXPath));
            MoveToElement.Go(driver, element);
            return element;
        }
        public static IWebElement Go(IWebDriver driver, IWebElement element)
        {
            if (driver is null) throw new Exception("Driver cannot be null.");
            string js = string.Format("window.scroll(0, {0});", element.Location.Y);
            ((IJavaScriptExecutor)driver).ExecuteScript(js);
            Actions Builder = new Actions(driver);
            Builder.MoveToElement(element).Build().Perform();
            return element;
        }
    }
}