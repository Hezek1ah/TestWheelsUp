﻿//Last edited by Kelly Bagley, 7/8/2021
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WheelsUpPages
{
    public static class ClickElement
    {
        public static void Go(IWebDriver driver, string elementXPath)
        {
            if (driver is null) throw new Exception("Driver cannot be null.");
            if (elementXPath is null) throw new Exception("XPath cannot be null.");
            if (elementXPath == string.Empty) throw new Exception("XPath cannot be empty string.");
            IWebElement element = driver.FindElement(By.XPath(elementXPath));
            element.Click();
        }
    }
}
