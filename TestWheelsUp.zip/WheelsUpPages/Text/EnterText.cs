﻿//Last edited by Kelly Bagley, 7/8/2021
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WheelsUpPages
{
    public static class EnterText
    {
        public static void Go(IWebDriver driver, string fieldXPath, string text)
        {
            if (driver is null) throw new Exception("Driver cannot be null.");
            if (fieldXPath is null) throw new Exception("Path cannot be null.");
            if (fieldXPath == string.Empty) throw new Exception("Path cannot be empty string.");
            if (text is null) throw new Exception("Text cannot be null.");
            if (text == string.Empty) throw new Exception("Text cannot be empty string.");
            IWebElement element = driver.FindElement(By.XPath(fieldXPath));
            element.SendKeys(text + Keys.Tab); //added tab to get cursor out of field and trigger saving of text.
        }
    }
}
