﻿//Last edited by Kelly Bagley, 7/8/2021
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WheelsUpPages
{
    public static class GetText
    {
        public static string Go(IWebDriver driver, string elementXPath)
        {
            if (driver is null) throw new Exception("Driver cannot be null.");
            if (elementXPath is null) throw new Exception("Element XPath cannot be null.");
            if (elementXPath == string.Empty) throw new Exception("Element XPath cannot be empty string.");
            IWebElement element = driver.FindElement(By.XPath(elementXPath));
            return element.Text;
        }
    }
}
