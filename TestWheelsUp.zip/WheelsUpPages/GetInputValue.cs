﻿//Last edited by Kelly Bagley, 7/9/2021
using OpenQA.Selenium;
using System;

namespace WheelsUpPages
{
    public static class GetInputValue
    {
        public static string Go(IWebDriver driver, string inputXPath)
        {
            if (driver is null) throw new Exception("Driver cannot be null.");
            if (inputXPath is null) throw new Exception("XPath cannot be null.");
            if (inputXPath == string.Empty) throw new Exception("XPath cannot be empty string.");
            return driver.FindElement(By.XPath(inputXPath)).GetAttribute("value");
        }
    }
}