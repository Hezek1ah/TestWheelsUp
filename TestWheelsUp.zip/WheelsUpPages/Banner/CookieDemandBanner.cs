﻿//Last edited by Kelly Bagley, 7/8/2021
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WheelsUpPages
{
    public static class CookieDemandBanner
    {
        public static string CookieDemandBannerCloser = "//mat-icon[text()='clear']";
    }
}
