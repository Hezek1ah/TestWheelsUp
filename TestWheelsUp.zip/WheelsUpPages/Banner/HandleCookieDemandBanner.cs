﻿//Last edited by Kelly Bagley, 7/8/2021
using OpenQA.Selenium;
using System;

namespace WheelsUpPages
{
    public static class HandleCookieDemandBanner
    {
        public static void Go(IWebDriver driver, string elementXPath)
        {
            if (driver is null) throw new Exception("Driver cannot be null.");
            if (elementXPath is null) throw new Exception("Element XPath cannot be null.");
            if (elementXPath == string.Empty) throw new Exception("Element XPath cannot be empty string.");
            IWebElement element = driver.FindElement(By.XPath(elementXPath));
            Go(driver, element);
        }
        public static void Go(IWebDriver driver, IWebElement element)
        {
            if (driver is null) throw new Exception("Driver cannot be null.");
            if (element is null) throw new Exception("Element cannot be null.");
            if (ElementIsPresent.Go(driver, CookieDemandBanner.CookieDemandBannerCloser))
            {
                IWebElement closer = driver.FindElement(By.XPath(CookieDemandBanner.CookieDemandBannerCloser));
                closer.Click();
                //SetFocusToElement.Go(driver, element);
            }
        }
    }
}