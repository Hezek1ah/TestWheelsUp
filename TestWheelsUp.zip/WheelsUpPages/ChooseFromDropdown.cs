﻿//Last edited by Kelly Bagley, 7/9/2021
using OpenQA.Selenium;
using System;

namespace WheelsUpPages
{
    public static class ChooseFromDropdown
    {
        public static void Go(IWebDriver driver, string dropDownTrigger, string choice)
        {
            if (driver is null) throw new Exception("Driver cannot be null.");
            if (dropDownTrigger is null) throw new Exception("Trigger cannot be null.");
            if (dropDownTrigger == string.Empty) throw new Exception("Trigger cannot be empty string.");
            if (choice is null) throw new Exception("Choice cannot be null.");
            if (choice == string.Empty) throw new Exception("Choice cannot be empty string.");
            ClickElement.Go(driver, dropDownTrigger);
            //NOTE: clicking on menuItem before dropdown finishes opening causes a ElementClickInterceptedException
            //The following try catch gives the dropdown one more chance to finish opening before failing.
            try
            {
                ClickElement.Go(driver, choice);
            }
            catch (OpenQA.Selenium.ElementClickInterceptedException)
            {
                ClickElement.Go(driver, choice);
            }
        }
    }
}