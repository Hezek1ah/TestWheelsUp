﻿//Last editec by Kelly Bagley, 7/8/2021
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;

namespace WheelsUpPages
{
    public class HomePage
    {
        public string EssentialDescription = "//p[contains(text(),'essential as your time in the sky')]";
        public string EssentialTitle = "//p[contains(text(),'essential as your time in the sky')]/../../h2";
        public string PhoneContact = "//a[contains(@href, 'tel:')]";
        public string EmailContact = "//a[contains(@href, 'mailto:')]";
        public string AddressContact = "//h4[text() = 'Find Us']/ancestor::div[@class='links']" +
            "//span[@class='base-label']";
        public string FlyMenuOption = "//a[contains(text(),'Fly')]";
        public string CoreMembershipSubMenuOption = "//a[text()='CORE MEMBERSHIP']";

        public HomePage(IWebDriver driver)
        {
            if (driver is null) throw new Exception("Driver passed to Home Page constructor cannot be null.");
        }
    }
}
