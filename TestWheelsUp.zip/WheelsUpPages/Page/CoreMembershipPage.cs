﻿//Last edited by Kelly Bagley, 7/8/2021
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;

namespace WheelsUpPages
{
    public class CoreMembershipPage
    {
        public string BecomingCoreMemberTitle = "//h1[contains(text(),'Becoming a Wheels Up Core Member is easy')]";
        public string InitiationFeeAmount = "//h3[contains(text(),'Initiation fee')]/following-sibling::p";
        public string LearnMore = "//h1[contains(text(),'Learn more today')]";
        public string FirstNameLabel = "//label[contains(@for,'FirstName-clone')]";
        public string FirstNameField = "//input[contains(@id,'FirstName-clone')]";
        public string LastNameLabel = "//label[contains(@for,'LastName-clone')]";
        public string LastNameField = "//input[contains(@id,'LastName-clone')]";
        public string ContinueButton = "//a[contains(text(),'CONTINUE')]";

        public CoreMembershipPage(IWebDriver driver)
        {
            if (driver is null) throw new Exception("Driver passed to Home Page constructor cannot be null.");
        }
    }
}
