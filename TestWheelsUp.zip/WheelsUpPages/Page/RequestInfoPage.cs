﻿//Last edited by Kelly Bagley, 7/9/2021
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;

namespace WheelsUpPages
{
    public class RequestInfoPage
    {
        #region Form Fields
        public string FirstNameField = "//input[contains(@id,'FirstName-clone')]";
        public string LastNameField = "//input[contains(@id,'LastName-clone')]";
        public string EmailField = "//input[contains(@id,'Email-clone')]";
        public string PhoneField = "//input[contains(@id,'Phone-clone')]";
        public string CompanyField = "//input[contains(@id,'Company__c-clone')]";
        public string AddressField = "//input[contains(@id,'Address-clone')]";
        public string CityField = "//input[contains(@id,'City-clone')]";
        public string ZipField = "//input[contains(@id,'PostalCode-clone')]";
        public string StateField = "//input[contains(@id,'State-clone')]";
        public string CountryField = "//input[contains(@id,'Country-clone')]";
        #endregion

        #region Form Questions
        public string PrivateFlightsQ = "//p[contains(text(), 'PRIVATE FLIGHTS')]";
        public string PrivateFlightDropDownTrigger = "//div[contains(@id,'Private_Flights')]";
        public string PrivateFlightAnswer1To5 = "//p[text() = '1-5']";
        public string PrivateFlightAnswerStore = "//div[contains(@id,'Private_Flights')]//p[@class='label']";
        public string PetsTravelYesLabel = "//div[contains(@id,'travel_with_pets')]//label[contains(@for, '0-clonecss')]";
        public string PetsTravelAnswerYesStore = "//div[contains(@id,'travel_with_pets')]//input[contains(@value, 'Yes')]";
        public string SecondHomeDropDownTrigger = "//div[contains(@id,'second_home')]";
        public string SecondHomeAnswerNo = "//p[text() = 'No']";
        public string SecondHomeAnswerStore = "//div[contains(@id,'second_home')]//p[@class='label']";
        public string CurrentlyTravelCommercialLabel =
            "//div[contains(@id,'currently_Travel')]//label[contains(@for, '0-clonecss')]";
        public string CurrentlyTravelAnswerCommercialStore = 
            "//div[contains(@id,'currently_Travel')]//input[contains(@value, 'Commercial')]";
        public string ProductInterestConnectLabel =
            "//div[contains(@id,'Product_Interest')]//label[contains(@for, '0-clonecss')]";
        public string ProductInterestAnswerConnectStore =
            "//div[contains(@id,'Product_Interest')]//input[contains(@value, 'Connect')]";
        public string LeadSourceDropDownTrigger = "//div[contains(@id,'leadSource')]";
        public string LeadSourceAnswerAdvertisement = "//p[text() = 'Advertisement']";
        public string LeadSourceAnswerStore = "//div[contains(@id,'leadSource')]//p[@class='label']";
        public string WebCommentText = "//div[contains(@id, 'WebFormComment')]//textarea";
        #endregion

        public RequestInfoPage(IWebDriver driver)
        {
            if (driver is null) throw new Exception("Driver passed to Home Page constructor cannot be null.");
        }
    }
}
