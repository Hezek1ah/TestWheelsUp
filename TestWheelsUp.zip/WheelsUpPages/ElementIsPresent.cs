﻿//Last edited by Kelly Bagley, 7/8/2021
using OpenQA.Selenium;
using System;
using System.Collections.Generic;

namespace WheelsUpPages
{
    public static class ElementIsPresent
    {
        public static bool Go(IWebDriver driver, string elementXPath)
        {
            IReadOnlyCollection<IWebElement> results = driver.FindElements(By.XPath(elementXPath));
            foreach (IWebElement element in results)
            {
                if (element.Enabled && element.Displayed) return true;
            }
            return false;
        }
    }
}