﻿//Last editec by Kelly Bagley, 7/7/2021
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;

namespace WheelsUpPages
{
    public static class SelectChromeBrowser
    {
        public static IWebDriver Go()
        {
            IWebDriver driver = new ChromeDriver();
            return driver;
        }
    }
}