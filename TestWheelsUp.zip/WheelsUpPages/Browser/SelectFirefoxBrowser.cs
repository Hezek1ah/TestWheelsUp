﻿//Last editec by Kelly Bagley, 7/7/2021
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;

namespace WheelsUpPages
{
    public static class SelectFirefoxBrowser
    {
        public static IWebDriver Go()
        {
            IWebDriver driver = new FirefoxDriver();
            return driver;
        }
    }
}