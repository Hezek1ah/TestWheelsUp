﻿//Last edited by Kelly Bagley, 7/7/2021
using OpenQA.Selenium;

namespace WheelsUpPages
{
    public static class DisposeOfBrowser
    {
        public static void Go(IWebDriver driver)
        {
            driver.Quit();
            driver.Dispose();
        }
    }
}