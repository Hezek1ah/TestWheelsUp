﻿//Last editec by Kelly Bagley, 7/7/2021
using OpenQA.Selenium;
using System;

namespace WheelsUpPages
{
    public static class SetupBrowser
    {
        public static void Go(IWebDriver driver, string url)
        {
            if (driver is null) throw new Exception("Driver cannot be null.");
            if (url is null) throw new Exception("URL cannot be null.");
            if (url == string.Empty) throw new Exception("URL cannot be empty string.");
            driver.Manage().Window.Maximize();
            driver.Url = url;
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
        }
    }
}