﻿//Last edited by Kelly Bagley, 7/8/2021
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using WheelsUpPages;

namespace TestWheelsUpPages
{
    public static class TestHandleCookieDemandBanner
    {
        private static HomePage _homePage;
        private static IWebDriver _driver;
        private static string _url = "https://wheelsup.com/";

        [SetUp]
        public static void Setup()
        {
            _driver = SelectChromeBrowser.Go();
            SetupBrowser.Go(_driver, _url);
            _homePage = new HomePage(_driver);
        }

        [Test]
        public static void TestInputNullDriver()
        {
            IWebElement element = _driver.FindElement(By.XPath(_homePage.AddressContact));
            Exception exception = Assert.Throws<Exception>(() => HandleCookieDemandBanner.Go(null, element));
            Assert.That(exception.Message == "Driver cannot be null.");
        }
        [Test]
        public static void TestInputEmptyElement()
        {
            Exception exception = Assert.Throws<Exception>(() => HandleCookieDemandBanner.Go(_driver, string.Empty));
            Assert.That(exception.Message == "Element XPath cannot be empty string.");
        }
        [Test]
        public static void TestElementGetsFocusAfterClose()
        {
            IWebElement element = _driver.FindElement(By.XPath(_homePage.AddressContact));
            MoveToElement.Go(_driver, element);
            HandleCookieDemandBanner.Go(_driver, element);
            Assert.That(element.Displayed);
        }

        [TearDown]
        public static void TearDown()
        {
            if (_driver != null) DisposeOfBrowser.Go(_driver);
        }
    }
}
