﻿//Last edited by Kelly Bagley, 7/9/2021
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using WheelsUpPages;

namespace TestWheelsUpPages
{
    public static class TestGetInputValue
    {
        private static RequestInfoPage _requestInfoPage;
        private static IWebDriver _driver;
        private static string _url = "https://wheelsup.com/request-info";

        [SetUp]
        public static void Setup()
        {
            _driver = SelectChromeBrowser.Go();
            SetupBrowser.Go(_driver, _url);
            _requestInfoPage = new RequestInfoPage(_driver);
        }

        [Test]
        public static void TestInputNullDriver()
        {
            Exception exception = Assert.Throws<Exception>(() => GetInputValue.Go(null, null));
            Assert.That(exception.Message == "Driver cannot be null.");
        }
        [Test]
        public static void TestInputNullXPath()
        {
            Exception exception = Assert.Throws<Exception>(() => GetInputValue.Go(_driver, null));
            Assert.That(exception.Message == "XPath cannot be null.");
        }
        [Test]
        public static void TestInputEmptyXPath()
        {
            Exception exception = Assert.Throws<Exception>(() => GetInputValue.Go(_driver, string.Empty));
            Assert.That(exception.Message == "XPath cannot be empty string.");
        }
        [Test]
        public static void TestHappyPath()
        {
            HandleCookieDemandBanner.Go(_driver, _requestInfoPage.FirstNameField);
            EnterText.Go(_driver, _requestInfoPage.FirstNameField, "Kelly");
            string firstName = GetInputValue.Go(_driver, _requestInfoPage.FirstNameField);
            Assert.That(firstName == "Kelly");
        }

        [TearDown]
        public static void TearDown()
        {
            if (_driver != null) DisposeOfBrowser.Go(_driver);
        }
    }
}
