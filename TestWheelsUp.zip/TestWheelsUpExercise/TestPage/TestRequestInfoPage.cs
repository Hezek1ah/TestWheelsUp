﻿//Last edited by Kelly Bagley, 7/9/2021
using NUnit.Framework;
using OpenQA.Selenium;
using WheelsUpPages;

namespace TestWheelsUpPages
{
    public static class TestRequestInfoPage
    {
        private static RequestInfoPage _requestInfoPage;
        private static IWebDriver _driver;
        private static string _url = "https://wheelsup.com/request-info";

        [SetUp]
        public static void Setup()
        {
            _driver = SelectChromeBrowser.Go();
            SetupBrowser.Go(_driver, _url);
            _requestInfoPage = new RequestInfoPage(_driver);
        }

        [Test]
        public static void TestFillOutForm()
        {
            //DO NOT SUBMIT!!!
            HandleCookieDemandBanner.Go(_driver, _requestInfoPage.EmailField);

            #region Form Fields
            EnterText.Go(_driver, _requestInfoPage.FirstNameField, "Kelly");
            string firstName = GetInputValue.Go(_driver, _requestInfoPage.FirstNameField);
            EnterText.Go(_driver, _requestInfoPage.LastNameField, "Bagley");
            string lastName = GetInputValue.Go(_driver, _requestInfoPage.LastNameField);
            EnterText.Go(_driver, _requestInfoPage.EmailField, "kellybagley@ebtek.com");
            string email = GetInputValue.Go(_driver, _requestInfoPage.EmailField);
            EnterText.Go(_driver, _requestInfoPage.PhoneField, "3609264644");
            string phone = GetInputValue.Go(_driver, _requestInfoPage.PhoneField);
            EnterText.Go(_driver, _requestInfoPage.CompanyField, "EBTek, LLC");
            string company = GetInputValue.Go(_driver, _requestInfoPage.CompanyField);
            EnterText.Go(_driver, _requestInfoPage.AddressField, "456 Columbia St.");
            string address = GetInputValue.Go(_driver, _requestInfoPage.AddressField);
            EnterText.Go(_driver, _requestInfoPage.CityField, "Pomeroy");
            string city = GetInputValue.Go(_driver, _requestInfoPage.CityField);
            EnterText.Go(_driver, _requestInfoPage.ZipField, "99347");
            string zip = GetInputValue.Go(_driver, _requestInfoPage.ZipField);
            EnterText.Go(_driver, _requestInfoPage.StateField, "WA");
            string state = GetInputValue.Go(_driver, _requestInfoPage.StateField);
            EnterText.Go(_driver, _requestInfoPage.CountryField, "USA");
            string country = GetInputValue.Go(_driver, _requestInfoPage.CountryField);

            Assert.That(firstName == "Kelly");
            Assert.That(lastName == "Bagley");
            Assert.That(email == "kellybagley@ebtek.com");
            Assert.That(phone == "3609264644");
            Assert.That(company == "EBTek, LLC");
            Assert.That(address == "456 Columbia St.");
            Assert.That(city == "Pomeroy");
            Assert.That(zip == "99347");
            Assert.That(state == "WA");
            Assert.That(country == "USA");
            #endregion

            #region Form Questions
            ChooseFromDropdown.Go
                (_driver, _requestInfoPage.PrivateFlightDropDownTrigger, _requestInfoPage.PrivateFlightAnswer1To5);
            ClickElement.Go(_driver, _requestInfoPage.PetsTravelYesLabel);
            ChooseFromDropdown.Go
                (_driver, _requestInfoPage.SecondHomeDropDownTrigger, _requestInfoPage.SecondHomeAnswerNo);
            ClickElement.Go(_driver, _requestInfoPage.CurrentlyTravelCommercialLabel);
            ClickElement.Go(_driver, _requestInfoPage.ProductInterestConnectLabel);
            ChooseFromDropdown.Go
                (_driver, _requestInfoPage.LeadSourceDropDownTrigger, _requestInfoPage.LeadSourceAnswerAdvertisement);
            EnterText.Go(_driver, _requestInfoPage.WebCommentText, "Do employees get any free flights?");

            string privateFlightsChoice = GetText.Go(_driver, _requestInfoPage.PrivateFlightAnswerStore);
            string petTravelChoice = GetInputValue.Go(_driver, _requestInfoPage.PetsTravelAnswerYesStore);
            string SecondHomeChoice = GetText.Go(_driver, _requestInfoPage.SecondHomeAnswerStore);
            string CurrentlyTravelChoice = GetInputValue.Go(_driver, _requestInfoPage.CurrentlyTravelAnswerCommercialStore);
            string ProductInterestChoice = GetInputValue.Go(_driver, _requestInfoPage.ProductInterestAnswerConnectStore);
            string LeadSourceChoice = GetText.Go(_driver, _requestInfoPage.LeadSourceAnswerStore);
            string question = GetInputValue.Go(_driver, _requestInfoPage.WebCommentText);

            Assert.That(privateFlightsChoice == "1-5");
            Assert.That(petTravelChoice == "Yes");
            Assert.That(SecondHomeChoice == "No");
            Assert.That(CurrentlyTravelChoice == "Commercial");
            Assert.That(ProductInterestChoice == "Wheels Up Connect Membership");
            Assert.That(LeadSourceChoice == "Advertisement");
            Assert.That(question == "Do employees get any free flights?");
            #endregion
        }

        [TearDown]
        public static void TearDown()
        {
            if (_driver != null) DisposeOfBrowser.Go(_driver);
        }
    }
}
