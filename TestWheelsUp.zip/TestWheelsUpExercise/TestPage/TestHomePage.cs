//Last edited by Kelly Bagley, 7/8/2021
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using WheelsUpPages;

namespace TestWheelsUpPages
{
    public static class TestHomePage
    {
        private static HomePage _homePage;
        private static IWebDriver _driver;
        private static string _url = "https://wheelsup.com/";

        [SetUp]
        public static void Setup()
        {
            _driver = SelectChromeBrowser.Go();
            SetupBrowser.Go(_driver, _url);
            _homePage = new HomePage(_driver);
        }

        [Test]
        public static void TestTitleAndDescription()
        {
            HandleCookieDemandBanner.Go(_driver, _homePage.EssentialDescription);
            string essentialDescription = GetText.Go(_driver, _homePage.EssentialDescription);
            string essentialTitle = GetText.Go(_driver, _homePage.EssentialTitle);
            Console.WriteLine(essentialTitle);
            Console.WriteLine(essentialDescription);
            Console.WriteLine();
            Assert.That(essentialTitle == "Next-level lifestyle");
            Assert.That(essentialDescription == 
                "Exceptional experiences on the ground are as essential as your time in the sky." +
                " A Wheels Up Membership means instant access to once-in-a-lifetime events" +
                " as well as a platform of exclusive member benefits through partnerships with coveted lifestyle brands.");
        }
        [Test]
        public static void TestContactInfo()
        {
            HandleCookieDemandBanner.Go(_driver, _homePage.PhoneContact);
            string phoneContact = GetText.Go(_driver, _homePage.PhoneContact);
            string emailContact = GetText.Go(_driver, _homePage.EmailContact);
            string addressContact = GetText.Go(_driver, _homePage.AddressContact);
            Console.WriteLine("PHONE: " + phoneContact);
            Console.WriteLine("EMAIL: " + emailContact);
            Console.WriteLine("ADDRESS: " + addressContact);
            Console.WriteLine();
            Assert.That(phoneContact == "855-FLY-8760");
            Assert.That(emailContact == "INFO@WHEELSUP.COM");
            Assert.That(addressContact == "601 West 26th Street" + Environment.NewLine
                + "New York, NY 10001");
        }
        [Test]
        public static void TestFlyCoreMember()
        {
            HandleCookieDemandBanner.Go(_driver, _homePage.FlyMenuOption);
            ClickElement.Go(_driver, _homePage.FlyMenuOption);
            ClickElement.Go(_driver, _homePage.CoreMembershipSubMenuOption);
            Assert.That(_driver.Url == "https://wheelsup.com/core-membership");
        }

        [TearDown]
        public static void TearDown()
        {
            if (_driver != null) DisposeOfBrowser.Go(_driver);
        }
    }
}