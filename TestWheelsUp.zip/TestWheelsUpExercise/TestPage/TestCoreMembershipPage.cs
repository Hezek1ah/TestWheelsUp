﻿//Last edited by Kelly Bagley, 7/8/2021
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using WheelsUpPages;

namespace TestWheelsUpPages
{
    public static class TestCoreMembershipPage
    {
        private static CoreMembershipPage _coreMembershipPage;
        private static IWebDriver _driver;
        private static string _url = "https://wheelsup.com/core-membership";

        [SetUp]
        public static void Setup()
        {
            _driver = SelectChromeBrowser.Go();
            SetupBrowser.Go(_driver, _url);
            _coreMembershipPage = new CoreMembershipPage(_driver);
        }

        [Test]
        public static void TestFeeAndLearnMoreTextEntry()
        {
            IWebElement element = MoveToElement.Go(_driver, _coreMembershipPage.BecomingCoreMemberTitle);
            HandleCookieDemandBanner.Go(_driver, element);
            string initiationFeeAmount = GetText.Go(_driver, _coreMembershipPage.InitiationFeeAmount);
            Console.WriteLine("INITIATION FEE: " + initiationFeeAmount);

            MoveToElement.Go(_driver, _coreMembershipPage.LearnMore);
            EnterText.Go(_driver, _coreMembershipPage.FirstNameField, "Kelly");
            EnterText.Go(_driver, _coreMembershipPage.LastNameField, "Bagley");
            ClickElement.Go(_driver, _coreMembershipPage.ContinueButton);

            Assert.That(initiationFeeAmount == "$17,500");
            Assert.That(_driver.Url == "https://wheelsup.com/request-info");
        }

        [TearDown]
        public static void TearDown()
        {
            if (_driver != null) DisposeOfBrowser.Go(_driver);
        }
    }
}
