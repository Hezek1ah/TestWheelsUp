﻿//Last edited by Kelly Bagley, 7/8/2021
using NUnit.Framework;
using OpenQA.Selenium;
using WheelsUpPages;

namespace TestWheelsUpPages
{
    public static class TestElementIsPresent
    {
        private static IWebDriver _driver;

        private static string _url = "https://wheelsup.com/";
        private static HomePage _homePage;

        [SetUp]
        public static void Setup()
        {
            _driver = SelectChromeBrowser.Go();
            SetupBrowser.Go(_driver, _url);
            _homePage = new HomePage(_driver);
        }

        [Test]
        public static void TestTrue()
        {
            Assert.That(ElementIsPresent.Go(_driver, _homePage.AddressContact));
        }
        [Test]
        public static void TestFalse()
        {
            Assert.That(!ElementIsPresent.Go(_driver, "//kelly"));
        }

        [TearDown]
        public static void TearDown()
        {
            if (_driver != null) DisposeOfBrowser.Go(_driver);
        }
    }
}
