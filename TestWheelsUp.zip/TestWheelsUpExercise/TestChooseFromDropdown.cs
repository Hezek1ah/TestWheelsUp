﻿//Last edited by Kelly Bagley, 7/9/2021
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using WheelsUpPages;

namespace TestWheelsUpPages
{
    public static class TestChooseFromDropdown
    {
        private static IWebDriver _driver;
        private static RequestInfoPage _requestInfoPage;
        private static string _url = "https://wheelsup.com/request-info";

        [SetUp]
        public static void Setup()
        {
            _driver = SelectChromeBrowser.Go();
            SetupBrowser.Go(_driver, _url);
            _requestInfoPage = new RequestInfoPage(_driver);
        }

        [Test]
        public static void TestInputNullDriver()
        {
            Exception exception = Assert.Throws<Exception>(() => ChooseFromDropdown.Go(null, null, null));
            Assert.That(exception.Message == "Driver cannot be null.");
        }
        [Test]
        public static void TestInputNullTrigger()
        {
            Exception exception = Assert.Throws<Exception>(() => ChooseFromDropdown.Go(_driver, null, null));
            Assert.That(exception.Message == "Trigger cannot be null.");
        }
        [Test]
        public static void TestInputEmptyTrigger()
        {
            Exception exception = Assert.Throws<Exception>(() => ChooseFromDropdown.Go(_driver, string.Empty, null));
            Assert.That(exception.Message == "Trigger cannot be empty string.");
        }
        [Test]
        public static void TestInputNullChoice()
        {
            Exception exception = Assert.Throws<Exception>(() => ChooseFromDropdown.Go
            (_driver, _requestInfoPage.PrivateFlightDropDownTrigger, null));
            Assert.That(exception.Message == "Choice cannot be null.");
        }
        [Test]
        public static void TestInputEmptyChoice()
        {
            Exception exception = Assert.Throws<Exception>(() => ChooseFromDropdown.Go
                (_driver, _requestInfoPage.PrivateFlightDropDownTrigger, string.Empty));
            Assert.That(exception.Message == "Choice cannot be empty string.");
        }
        [Test]
        public static void TestHappyPath()
        {
            HandleCookieDemandBanner.Go(_driver, _requestInfoPage.PrivateFlightsQ);
            ChooseFromDropdown.Go
                (_driver, _requestInfoPage.PrivateFlightDropDownTrigger, _requestInfoPage.PrivateFlightAnswer1To5);
            string privateFlightsChoice = GetText.Go(_driver, _requestInfoPage.PrivateFlightAnswerStore);

            Assert.That(privateFlightsChoice == "1-5");
        }

        [TearDown]
        public static void TearDown()
        {
            if (_driver != null) DisposeOfBrowser.Go(_driver);
        }
    }
}
