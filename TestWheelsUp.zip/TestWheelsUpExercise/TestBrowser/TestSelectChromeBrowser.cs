﻿//Last edited by Kelly Bagley, 7/7/2021
using NUnit.Framework;
using WheelsUpPages;
using System;
using OpenQA.Selenium;

namespace TestWheelsUpPages
{
    public static class TestSelectChromeBrowser
    {
        public static IWebDriver Driver;

        private static string _url = "https://wheelsup.com/";

        [SetUp]
        public static void Setup()
        {
        }

        [Test]
        public static void Test()
        {
            Driver = SelectChromeBrowser.Go();
            Assert.That(Driver != null);
        }

        [TearDown]
        public static void TearDown()
        {
            if (Driver != null) DisposeOfBrowser.Go(Driver);
        }
    }
}
