﻿//Last edited by Kelly Bagley, 7/7/2021
using NUnit.Framework;
using OpenQA.Selenium;
using WheelsUpPages;

namespace TestWheelsUpPages
{
    public static class TestSelectFirefoxBrowser
    {
        public static IWebDriver Driver;

        private static string _url = "https://wheelsup.com/";

        [SetUp]
        public static void Setup()
        {
        }

        [Test]
        public static void Test()
        {
            Driver = SelectFirefoxBrowser.Go();
            Assert.That(Driver != null);
        }

        [TearDown]
        public static void TearDown()
        {
            if (Driver != null) DisposeOfBrowser.Go(Driver);
        }
    }
}
