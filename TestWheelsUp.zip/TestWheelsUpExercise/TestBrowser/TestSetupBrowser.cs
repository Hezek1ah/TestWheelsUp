﻿//Last edited by Kelly Bagley, 7/7/2021
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using WheelsUpPages;

namespace TestWheelsUpPages
{
    public static class TestSetupBrowser
    {
        private static IWebDriver _driver;
        private static string _url = "https://wheelsup.com/";

        [SetUp]
        public static void Setup()
        {
            _driver = SelectChromeBrowser.Go();
        }

        [Test]
        public static void TestInputNullDriver()
        {
            Exception exception = Assert.Throws<Exception>(() => SetupBrowser.Go(null, null));
            Assert.That(exception.Message == "Driver cannot be null.");
        }
        [Test]
        public static void TestInputNullURL()
        {
            Exception exception = Assert.Throws<Exception>(() => SetupBrowser.Go(_driver, null));
            Assert.That(exception.Message == "URL cannot be null.");
        }
        [Test]
        public static void TestInputEmptyURL()
        {
            Exception exception = Assert.Throws<Exception>(() => SetupBrowser.Go(_driver, string.Empty));
            Assert.That(exception.Message == "URL cannot be empty string.");
        }
        [Test]
        public static void TestHappyPath()
        {
            SetupBrowser.Go(_driver, _url);
            Assert.That(ElementIsPresent.Go(_driver, "//a"));
        }

        [TearDown]
        public static void TearDown()
        {
            if (_driver != null) DisposeOfBrowser.Go(_driver);
        }
    }
}
