﻿//Last edited by Kelly Bagley, 7/8/2021
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using WheelsUpPages;

namespace TestWheelsUpPages
{
    public static class TestClickElement
    {
        private static HomePage _homePage;
        private static IWebDriver _driver;
        private static string _url = "https://wheelsup.com/";

        [SetUp]
        public static void Setup()
        {
            _driver = SelectChromeBrowser.Go();
            SetupBrowser.Go(_driver, _url);
            _homePage = new HomePage(_driver);
        }

        [Test]
        public static void TestInputNullDriver()
        {
            Exception exception = Assert.Throws<Exception>(() => ClickElement.Go(null, null));
            Assert.That(exception.Message == "Driver cannot be null.");
        }
        [Test]
        public static void TestInputNullXPath()
        {
            Exception exception = Assert.Throws<Exception>(() => ClickElement.Go(_driver, null));
            Assert.That(exception.Message == "XPath cannot be null.");
        }
        [Test]
        public static void TestInputEmtpyXPath()
        {
            Exception exception = Assert.Throws<Exception>(() => ClickElement.Go(_driver, string.Empty));
            Assert.That(exception.Message == "XPath cannot be empty string.");
        }
        [Test]
        public static void TestHappyPath()
        {
            IWebElement element = MoveToElement.Go(_driver, _homePage.AddressContact);
            HandleCookieDemandBanner.Go(_driver, element);
            ClickElement.Go(_driver, _homePage.AddressContact);
            Assert.That(element.Displayed);
        }

        [TearDown]
        public static void TearDown()
        {
            if (_driver != null) DisposeOfBrowser.Go(_driver);
        }
    }
}
