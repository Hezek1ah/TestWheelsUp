﻿//Last edited by Kelly Bagley, 7/8/2021
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using WheelsUpPages;

namespace TestWheelsUpPages
{
    public static class TestMoveToElement
    {
        private static HomePage _homePage;
        private static IWebDriver _driver;
        private static string _url = "https://wheelsup.com/";

        [SetUp]
        public static void Setup()
        {
            _driver = SelectChromeBrowser.Go();
            SetupBrowser.Go(_driver, _url);
            _homePage = new HomePage(_driver);
        }

        [Test]
        public static void TestStringNullDriver()
        {
            Exception exception = Assert.Throws<Exception>(() => MoveToElement.Go(null, _homePage.AddressContact));
            Assert.That(exception.Message == "Driver cannot be null.");
        }
        [Test]
        public static void TestStringEmptyString()
        {
            Exception exception = Assert.Throws<Exception>(() => MoveToElement.Go(_driver, string.Empty));
            Assert.That(exception.Message == "Element XPath cannot be empty string.");
        }
        [Test]
        public static void TestString()
        {
            IWebElement element = MoveToElement.Go(_driver, _homePage.AddressContact);
            HandleCookieDemandBanner.Go(_driver, element);
            Assert.That(element.Displayed);
        }
        [Test]
        public static void TestElementNullDriver()
        {
            Exception exception = Assert.Throws<Exception>(() => MoveToElement.Go(null, _homePage.AddressContact));
            Assert.That(exception.Message == "Driver cannot be null.");
        }
        [Test]
        public static void TestELement()
        {
            IWebElement element = _driver.FindElement(By.XPath(_homePage.AddressContact));
            MoveToElement.Go(_driver, element);
            HandleCookieDemandBanner.Go(_driver, element);
            Assert.That(element.Displayed);
        }

        [TearDown]
        public static void TearDown()
        {
            if (_driver != null) DisposeOfBrowser.Go(_driver);
        }
    }
}
