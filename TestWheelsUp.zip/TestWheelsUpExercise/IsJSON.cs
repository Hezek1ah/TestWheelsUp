﻿//Last edited by Kelly Bagley, 7/12/2021
using Newtonsoft.Json;
using System;
using System.Text.Json;

namespace Verification
{
    public static class IsJSON
    {
        public static bool Go(string stringBeingTested)
        {
            if (stringBeingTested is null) throw new Exception("String being tested cannot be null.");
            if (stringBeingTested == string.Empty) throw new Exception("String being tested cannot be an empty string.");
            try
            {
                JsonDocument.Parse(stringBeingTested);
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }
    }
}