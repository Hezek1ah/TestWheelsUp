﻿//Last edited by Kelly Bagley, 7/8/2021
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using WheelsUpPages;

namespace TestWheelsUpPages
{
    public static class TestGetText
    {
        private static IWebDriver _driver;
        private static string _url = "https://wheelsup.com/";

        [SetUp]
        public static void Setup()
        {
            _driver = SelectChromeBrowser.Go();
            SetupBrowser.Go(_driver, _url);
        }

        [Test]
        public static void TestInputNullDriver()
        {
            Exception exception = Assert.Throws<Exception>(() => GetText.Go(null, null));
            Assert.That(exception.Message == "Driver cannot be null.");
        }
        [Test]
        public static void TestInputNullString()
        {
            Exception exception = Assert.Throws<Exception>(() => GetText.Go(_driver, null));
            Assert.That(exception.Message == "Element XPath cannot be null.");
        }
        [Test]
        public static void TestInputEmptyString()
        {
            Exception exception = Assert.Throws<Exception>(() => GetText.Go(_driver, string.Empty));
            Assert.That(exception.Message == "Element XPath cannot be empty string.");
        }
        [Test]
        public static void TestHappyPath()
        {
            string text = GetText.Go(_driver, "//h4[text() = 'Find Us']");
            Assert.That(text == "Find Us");
        }

        [TearDown]
        public static void TearDown()
        {
            if (_driver != null) DisposeOfBrowser.Go(_driver);
        }
    }
}
