﻿//Last edited by Kelly Bagley, 7/8/2021
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using WheelsUpPages;

namespace TestWheelsUpPages
{
    public static class TestEnterText
    {
        private static CoreMembershipPage _coreMembershipPage;
        private static IWebDriver _driver;
        private static string _url = "https://wheelsup.com/core-membership";

        [SetUp]
        public static void Setup()
        {
            _driver = SelectChromeBrowser.Go();
            SetupBrowser.Go(_driver, _url);
            _coreMembershipPage = new CoreMembershipPage(_driver);
        }

        [Test]
        public static void TestInputNullDriver()
        {
            Exception exception = Assert.Throws<Exception>(() => EnterText.Go(null, null, null));
            Assert.That(exception.Message == "Driver cannot be null.");
        }
        [Test]
        public static void TestInputNullPath()
        {
            Exception exception = Assert.Throws<Exception>(() => EnterText.Go(_driver, null, null));
            Assert.That(exception.Message == "Path cannot be null.");
        }
        [Test]
        public static void TestInputEmptyPath()
        {
            Exception exception = Assert.Throws<Exception>(() => EnterText.Go(_driver, string.Empty, null));
            Assert.That(exception.Message == "Path cannot be empty string.");
        }
        [Test]
        public static void TestInputNullText()
        {
            Exception exception = Assert.Throws<Exception>(() => EnterText.Go
            (_driver, _coreMembershipPage.FirstNameField, null));
            Assert.That(exception.Message == "Text cannot be null.");
        }
        [Test]
        public static void TestHappyPath()
        {
            HandleCookieDemandBanner.Go(_driver, _coreMembershipPage.LearnMore);
            MoveToElement.Go(_driver, _coreMembershipPage.LearnMore);
            EnterText.Go(_driver, _coreMembershipPage.LastNameField, "Bagley");
            string result = _driver.FindElement(By.XPath(_coreMembershipPage.LastNameField)).GetAttribute("value");
            Assert.That(result == "Bagley");
        }

        [TearDown]
        public static void TearDown()
        {
            if (_driver != null) DisposeOfBrowser.Go(_driver);
        }
    }
}
