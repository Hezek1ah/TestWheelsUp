//Last edited by Kelly Bagley, 7/12/2021
using NUnit.Framework;
using System;
using System.Collections.Generic;
using Verification;

namespace TestVerification
{
    public class TestGetJSONResponse
    {
        private static string endpoint = "https://marketingapi.wheelsup.com/api/initial-data/";

        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestInputNull()
        {
            var exception = Assert.Throws<Exception>(() => GetJSONResponse.Go(null));
            Assert.That(exception.Message == "Endpoint cannot be null.");
        }
        [Test]
        public void TestInputEmpty()
        {
            var exception = Assert.Throws<Exception>(() => GetJSONResponse.Go(string.Empty));
            Assert.That(exception.Message == "Endpoint cannot be an empty string.");
        }
        [Test]
        public void TestInputString()
        {
            string jsonResponse = GetJSONResponse.Go(endpoint);
            Assert.That(IsJSON.Go(jsonResponse));
        }
    }
}