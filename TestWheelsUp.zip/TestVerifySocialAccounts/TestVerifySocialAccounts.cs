//Last edited by Kelly Bagley, 7/12/2021
using NUnit.Framework;
using System;
using System.Collections.Generic;
using Verification;

namespace TestVerification
{
    public class TestVerifySocialAccounts
    {
        private const string badInstagram = "https://instagram.com/wheelsup8760";
        private const string badTwitter = "http://twitter.com/WheelsUp";
        private const string goodInstagram = "http://instagram.com/wheelsup8760";
        private const string goodTwitter = "https://twitter.com/WheelsUp";
        private const string emptyString = "";
        private static Dictionary<string, string> accountsToVerify = new Dictionary<string, string>();

        [SetUp]
        public void Setup()
        {
            accountsToVerify.Clear();
        }

        [Test]
        public void TestInputDictionaryNull()
        {
            Exception exception = Assert.Throws<Exception>(() => VerifySocialAccounts.Go(null));
            Assert.That(exception.Message == "List of accounts to verify cannot be null.");
        }
        [Test]
        public void TestInputDictionaryEmpty()
        {
            Exception exception = Assert.Throws<Exception>(() => VerifySocialAccounts.Go(new Dictionary<string, string>()));
            Assert.That(exception.Message == "List of accounts to verify cannot be empty.");
        }
        [Test]
        public void TestInput1URLNull()
        {
            accountsToVerify.Add("Twitter", null);
            Exception exception = Assert.Throws<Exception>(() => VerifySocialAccounts.Go(accountsToVerify));
            Assert.That(exception.Message == "Account URL cannot be null.");
        }
        [Test]
        public void TestInput1URLEmpty()
        {
            accountsToVerify.Add("Twitter", emptyString);
            Exception exception = Assert.Throws<Exception>(() => VerifySocialAccounts.Go(accountsToVerify));
            Assert.That(exception.Message == "Account URL cannot be an empty string.");
        }
        [Test]
        public void TestInput1ItemBad()
        {
            accountsToVerify.Add("twitter", badTwitter);
            string result = VerifySocialAccounts.Go(accountsToVerify);
            Assert.That(result == "Cannot verify account: twitter" + Environment.NewLine);
        }
        [Test]
        public void TestInput1ItemGood()
        {
            accountsToVerify.Add("twitter", goodTwitter);
            string result = VerifySocialAccounts.Go(accountsToVerify);
            Assert.That(result == "Verified account: twitter" + Environment.NewLine);
        }
        [Test]
        public void TestInput2ItemsBadBad()
        {
            accountsToVerify.Add("instagram", badInstagram);
            accountsToVerify.Add("twitter", badTwitter);
            string result = VerifySocialAccounts.Go(accountsToVerify);
            Assert.That(result == "Cannot verify account: instagram" + Environment.NewLine +
                "Cannot verify account: twitter" + Environment.NewLine);
        }
        [Test]
        public void TestInput2ItemsBadGood()
        {
            accountsToVerify.Add("instagram", badInstagram);
            accountsToVerify.Add("twitter", goodTwitter);
            string result = VerifySocialAccounts.Go(accountsToVerify);
            Assert.That(result == "Cannot verify account: instagram" + Environment.NewLine +
                "Verified account: twitter" + Environment.NewLine);
        }
        [Test]
        public void TestInput2ItemsGoodBad()
        {
            accountsToVerify.Add("instagram", goodInstagram);
            accountsToVerify.Add("twitter", badTwitter);
            string result = VerifySocialAccounts.Go(accountsToVerify);
            Assert.That(result == "Verified account: instagram" + Environment.NewLine +
                "Cannot verify account: twitter" + Environment.NewLine);
        }
        [Test]
        public void TestInput2ItemsGoodGood()
        {
            accountsToVerify.Add("instagram", goodInstagram);
            accountsToVerify.Add("twitter", goodTwitter);
            string result = VerifySocialAccounts.Go(accountsToVerify);
            Assert.That(result == "Verified account: instagram" + Environment.NewLine +
                "Verified account: twitter" + Environment.NewLine);
        }
    }
}