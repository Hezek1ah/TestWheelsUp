//Last edited by Kelly Bagley, 7/12/2021
using NUnit.Framework;
using System;
using System.Collections.Generic;
using Verification;

namespace TestVerification
{
    public class TestIsJSON
    {
        private static string notJSON = "xxx";
        private static string JSON = "{\"key\":\"value\"";

        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestInputNull()
        {
            var exception = Assert.Throws<Exception>(() => IsJSON.Go(null));
            Assert.That(exception.Message == "String being tested cannot be null.");
        }
        [Test]
        public void TestInputEmpty()
        {
            var exception = Assert.Throws<Exception>(() => IsJSON.Go(string.Empty));
            Assert.That(exception.Message == "String being tested cannot be an empty string.");
        }
        [Test]
        public void TestOutputFalse()
        {
            Assert.False(IsJSON.Go(notJSON));
        }
        [Test]
        public void TestOutputTrue()
        {
            Assert.False(IsJSON.Go(JSON));
        }
    }
}