﻿//Last edited by Kelly Bagley, 7/12/2021
using System;
using System.IO;
using System.Net;

namespace Verification
{
    public static class GetJSONResponse
    {
        public static string Go(string endpoint)
        {
            if (endpoint is null) throw new Exception("Endpoint cannot be null.");
            if (endpoint == string.Empty) throw new Exception("Endpoint cannot be an empty string.");
            string result;
            var httpRequest = (HttpWebRequest)WebRequest.Create(endpoint);
            httpRequest.Accept = "application/json";

            var httpResponse = (HttpWebResponse)httpRequest.GetResponse();

            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                result = streamReader.ReadToEnd();
            }
            return result;
        }
    }
}