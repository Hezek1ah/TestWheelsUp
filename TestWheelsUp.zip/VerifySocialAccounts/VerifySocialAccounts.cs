﻿//Last edited by Kelly Bagley, 7/12/2021
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Formatting;
using System.IO;
using System.Net;
using System.Text.Json;

namespace Verification
{
    public static class VerifySocialAccounts
    {
        private static string endpoint = "https://marketingapi.wheelsup.com/api/initial-data/";
        private static string jsonResponse;
        private static JsonElement socialAccounts;

        public static string Go(Dictionary<string, string> accountsToVerify)
        {
            string result = string.Empty;

            if (accountsToVerify is null) throw new Exception("List of accounts to verify cannot be null.");
            if (accountsToVerify.Count == 0) throw new Exception("List of accounts to verify cannot be empty.");

            jsonResponse = GetJSONResponse.Go(endpoint);
            using (var document = JsonDocument.Parse(jsonResponse))
            {
                JsonElement root = document.RootElement;
                try
                {
                    socialAccounts = root.GetProperty("keys");
                }
                catch (Exception)
                {
                    try
                    {
                        socialAccounts = root.GetProperty("redirects");
                        throw new Exception("Redirected when attempting to communicate with the endpoint.");
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }

                foreach (KeyValuePair<string, string> accountToVerify in accountsToVerify)
                {
                    string accountName = accountToVerify.Key;
                    string accountURL = accountToVerify.Value;
                    if (accountURL is null) throw new Exception("Account URL cannot be null.");
                    if (accountURL == string.Empty) throw new Exception("Account URL cannot be an empty string.");
                    JsonElement foundValue;
                    if (socialAccounts.TryGetProperty(accountName, out foundValue))
                    {
                        if (foundValue.ToString() == accountURL) result += "Verified account: " + accountName;
                        else result += "Cannot verify account: " + accountName;
                    }
                    else result += "Cannot verify account: " + accountName;
                    result += Environment.NewLine;
                }
            }
            return result;
        }
    }
}
